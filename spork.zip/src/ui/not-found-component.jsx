import React from "react";

export class NotFoundComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return <div>404 not found</div>;
    }
}